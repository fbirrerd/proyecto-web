# utils/logger.py
import os
import logging
from datetime import datetime

# Crear carpeta de logs si no existe
log_dir = "/app/logs"
os.makedirs(log_dir, exist_ok=True)

# Logger por día
def get_logger():
    today = datetime.now().strftime("%Y-%m-%d")
    log_filename = os.path.join(log_dir, f"db_log_{today}.log")
    
    # Configurar el logger
    logging.basicConfig(
        filename=log_filename,
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    
    logger = logging.getLogger()
    return logger
