from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import Optional
from app.crud import create_usuario, get_usuario, update_usuario, delete_usuario

router = APIRouter(prefix="/usuarios", tags=["Usuarios"])

# DTO o esquema de usuario
class Usuario(BaseModel):
    nombre: str
    correo: str

# Middleware de validación (simulado)
def validar_usuario():
    return True

@router.post("/", status_code=201)
async def create_user(usuario: Usuario, val=Depends(validar_usuario)):
    return await create_usuario(usuario)

@router.get("/{id}")
async def read_user(id: int, val=Depends(validar_usuario)):
    user = await get_usuario(id)
    if not user:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")
    return user

@router.put("/{id}")
async def update_user(id: int, usuario: Usuario, val=Depends(validar_usuario)):
    success = await update_usuario(id, usuario)
    if not success:
        raise HTTPException(status_code=404, detail="No se pudo actualizar")
    return {"success": True}

@router.delete("/{id}")
async def delete_user(id: int, val=Depends(validar_usuario)):
    success = await delete_usuario(id)
    if not success:
        raise HTTPException(status_code=404, detail="No se pudo eliminar")
    return {"success": True}
