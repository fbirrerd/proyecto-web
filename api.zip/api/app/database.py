# app/database.py
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from dotenv import load_dotenv
import os
from utils.logger import get_logger  # Asegúrate de que esta línea esté presente


# Cargar variables del entorno
load_dotenv()

# Obtener el logger
logger = get_logger()  # Llamar a la función get_logger() para obtener el logger

# Variables de entorno para PostgreSQL
DB_USER = os.getenv("POSTGRES_USER")
DB_PASSWORD = os.getenv("POSTGRES_PASSWORD")
DB_HOST = "postgres"  # Nombre del servicio en docker-compose
DB_PORT = os.getenv("POSTGRES_PORT", "5432")
DB_NAME = os.getenv("POSTGRES_DB")

# Crear el string de conexión
DATABASE_URL = f"postgresql+psycopg2://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

try:
    if not DATABASE_URL:
        raise ValueError("DATABASE_URL no está definido en las variables de entorno.")

    # Mostrar en logs
    logger.info(f"Conectando a la base de datos: {DATABASE_URL}")

    # Crear engine y sesión
    engine = create_engine(DATABASE_URL)
    SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
    Base = declarative_base()

except Exception as e:
    logger.error(f"Ocurrió un error: {e}")
    raise