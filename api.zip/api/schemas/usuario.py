from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List
from datetime import datetime

# Propiedades compartidas básicas
class UsuarioBase(BaseModel):
    nombre_usuario: str = Field(..., min_length=3, max_length=50)
    email: EmailStr

# Propiedades para la creación (recibe la contraseña en texto plano)
class UsuarioCreate(UsuarioBase):
    contrasena: str = Field(..., min_length=6)

# Propiedades para la actualización (opcionales)
class UsuarioUpdate(BaseModel):
    nombre_usuario: Optional[str] = Field(None, min_length=3, max_length=50)
    email: Optional[EmailStr] = None
    estado: Optional[int] = Field(None, ge=0, le=1) # 0 o 1

# Propiedades para leer (devuelve datos sin la contraseña)
class UsuarioRead(UsuarioBase):
    id: int
    estado: int
    fecha_creacion: datetime
    fecha_modificacion: datetime

    class Config:
        from_attributes = True # Permite mapear desde el modelo SQLAlchemy

# Para login (se usa en auth)
class UsuarioLogin(BaseModel):
    username: str # Puede ser email o nombre_usuario
    password: str

# Esquema para cambiar contraseña
class UsuarioChangePassword(BaseModel):
    current_password: str
    new_password: str = Field(..., min_length=6)