from sqlalchemy import Column, Integer, String, Boolean, Text, TIMESTAMP, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime
from .database import Base

class Menu(Base):
    __tablename__ = 'menu'
    
    id = Column(Integer, primary_key=True, index=True)
    empresa_id = Column(Integer, ForeignKey('empresa.id'))
    nombre = Column(String, nullable=False)
    tipo = Column(Text, nullable=False)
    valor = Column(String, nullable=False)
    icono = Column(String)
    orden = Column(Integer)
    padre_id = Column(Integer, ForeignKey('menu.id'))
    fecha_creacion = Column(TIMESTAMP, default=datetime.utcnow)
    fecha_modificacion = Column(TIMESTAMP, default=datetime.utcnow, onupdate=datetime.utcnow)
    estado = Column(Boolean, default=False)

    # Relaciones
    empresa = relationship("Empresa", back_populates="menus")
    padre_menu = relationship("Menu", remote_side=[id])
