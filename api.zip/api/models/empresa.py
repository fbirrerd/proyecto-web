from sqlalchemy import Column, Integer, String, Boolean, TIMESTAMP, DateTime
from sqlalchemy.orm import relationship
from datetime import datetime
from .database import Base

class Empresa(Base):
    __tablename__ = 'empresa'
    
    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String, unique=True, nullable=False)
    fecha_creacion = Column(TIMESTAMP, default=datetime.utcnow)
    fecha_modificacion = Column(TIMESTAMP, default=datetime.utcnow, onupdate=datetime.utcnow)
    estado = Column(Boolean, default=False)  # 0: Habilitado, 1: Deshabilitado

    # Relación con otras tablas
    menus = relationship("Menu", back_populates="empresa")
    usuario_empresas = relationship("UsuarioEmpresa", back_populates="empresa")
