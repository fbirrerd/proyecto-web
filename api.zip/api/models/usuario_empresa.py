from sqlalchemy import Column, Integer, Date, TIMESTAMP, ForeignKey
from datetime import datetime
from .database import Base

class UsuarioEmpresa(Base):
    __tablename__ = 'usuario_empresa'
    
    usuario_id = Column(Integer, ForeignKey('usuario.id'), primary_key=True)
    empresa_id = Column(Integer, ForeignKey('empresa.id'), primary_key=True)
    fecha_inicio = Column(Date, nullable=False)
    fecha_fin = Column(Date)
    fecha_creacion = Column(TIMESTAMP, default=datetime.utcnow)
    fecha_modificacion = Column(TIMESTAMP, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relaciones
    usuario = relationship("Usuario", back_populates="usuario_empresas")
    empresa = relationship("Empresa", back_populates="usuario_empresas")
