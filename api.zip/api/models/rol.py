from sqlalchemy import Column, Integer, String, Text, Boolean, TIMESTAMP
from datetime import datetime
from .database import Base

class Rol(Base):
    __tablename__ = 'rol'
    
    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String, unique=True, nullable=False)
    descripcion = Column(Text)
    fecha_creacion = Column(TIMESTAMP, default=datetime.utcnow)
    fecha_modificacion = Column(TIMESTAMP, default=datetime.utcnow, onupdate=datetime.utcnow)
    estado = Column(Boolean, default=False)
