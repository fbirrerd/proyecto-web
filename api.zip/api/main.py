from fastapi import FastAPI
from app import models, database
from app.routes import usuario
from app.models import usuario
import os

# Crea las tablas
models.Base.metadata.create_all(bind=database.engine)

app = FastAPI(title=os.getenv("APP_NAME", "Mi API FastAPI"))

# Incluye las rutas de usuarios
app.include_router(usuarios.router)

@app.get("/")
def read_root():
    return {
        "message": "API funcionando",
        "app_name": os.getenv("APP_NAME"),
        "environment": os.getenv("ENVIRONMENT")
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app",
                host=os.getenv("API_HOST", "0.0.0.0"),
                port=int(os.getenv("API_PORT", 8000)),
                reload=os.getenv("DEBUG", "False").lower() == "true")
