from sqlalchemy.orm import Session
from .. import models, schemas
from ..utils import security # Importa las funciones de seguridad
import logging

logger = logging.getLogger('app.crud.usuario')

def get_by_id(db: Session, user_id: int) -> models.Usuario | None:
    """Obtiene un usuario por su ID."""
    return db.query(models.Usuario).filter(models.Usuario.id == user_id).first()

def get_by_email(db: Session, email: str) -> models.Usuario | None:
    """Obtiene un usuario por su email."""
    return db.query(models.Usuario).filter(models.Usuario.email == email).first()

def get_by_username(db: Session, username: str) -> models.Usuario | None:
    """Obtiene un usuario por su nombre de usuario."""
    return db.query(models.Usuario).filter(models.Usuario.nombre_usuario == username).first()

def get_multi(db: Session, skip: int = 0, limit: int = 100) -> list[models.Usuario]:
    """Obtiene una lista de usuarios con paginación."""
    return db.query(models.Usuario).offset(skip).limit(limit).all()

def create(db: Session, user_in: schemas.UsuarioCreate) -> models.Usuario:
    """Crea un nuevo usuario."""
    # Hashea la contraseña antes de guardarla
    hashed_password = security.get_password_hash(user_in.contrasena)
    db_user = models.Usuario(
        nombre_usuario=user_in.nombre_usuario,
        email=user_in.email,
        contrasena_hash=hashed_password # Guarda el hash
        # estado por defecto es 0 (Habilitado) según el modelo
    )
    try:
        db.add(db_user)
        db.commit()
        db.refresh(db_user)
        logger.info(f"Usuario creado: {db_user.nombre_usuario} (ID: {db_user.id})")
        return db_user
    except Exception as e:
        db.rollback()
        logger.error(f"Error al crear usuario {user_in.nombre_usuario}: {e}", exc_info=True)
        raise # Relanza la excepción para manejo en el router

def update(db: Session, db_user: models.Usuario, user_in: schemas.UsuarioUpdate) -> models.Usuario:
    """Actualiza un usuario existente."""
    update_data = user_in.model_dump(exclude_unset=True) # Obtiene solo los campos proporcionados

    for key, value in update_data.items():
        setattr(db_user, key, value)

    try:
        db.add(db_user) # Agrega el objeto modificado a la sesión
        db.commit()
        db.refresh(db_user)
        logger.info(f"Usuario actualizado: {db_user.nombre_usuario} (ID: {db_user.id})")
        return db_user
    except Exception as e:
        db.rollback()
        logger.error(f"Error al actualizar usuario {db_user.nombre_usuario}: {e}", exc_info=True)
        raise

def delete(db: Session, user_id: int) -> models.Usuario | None:
    """Elimina un usuario por ID."""
    db_user = get_by_id(db, user_id)
    if db_user:
        try:
            db.delete(db_user)
            db.commit()
            logger.info(f"Usuario eliminado: {db_user.nombre_usuario} (ID: {user_id})")
            return db_user
        except Exception as e:
            db.rollback()
            logger.error(f"Error al eliminar usuario ID {user_id}: {e}", exc_info=True)
            raise
    logger.warning(f"Intento de eliminar usuario ID {user_id} no encontrado.")
    return None

def change_password(db: Session, db_user: models.Usuario, new_password: str) -> models.Usuario:
    """Cambia la contraseña de un usuario (ya verificado)."""
    hashed_password = security.get_password_hash(new_password)
    db_user.contrasena_hash = hashed_password
    try:
        db.add(db_user)
        db.commit()
        db.refresh(db_user)
        logger.info(f"Contraseña cambiada para usuario: {db_user.nombre_usuario}")
        return db_user
    except Exception as e:
        db.rollback()
        logger.error(f"Error al cambiar contraseña para usuario {db_user.nombre_usuario}: {e}", exc_info=True)
        raise

# --- Funciones para relaciones (ejemplos) ---

def add_role_to_user(db: Session, user: models.Usuario, role: models.Rol) -> None:
    """Añade un rol a un usuario."""
    if role not in user.roles:
        user.roles.append(role)
        try:
            db.commit()
            logger.info(f"Rol '{role.nombre}' añadido a usuario '{user.nombre_usuario}'")
        except Exception as e:
            db.rollback()
            logger.error(f"Error añadiendo rol '{role.nombre}' a usuario '{user.nombre_usuario}': {e}", exc_info=True)
            raise

def remove_role_from_user(db: Session, user: models.Usuario, role: models.Rol) -> None:
    """Quita un rol a un usuario."""
    if role in user.roles:
        user.roles.remove(role)
        try:
            db.commit()
            logger.info(f"Rol '{role.nombre}' quitado de usuario '{user.nombre_usuario}'")
        except Exception as e:
            db.rollback()
            logger.error(f"Error quitando rol '{role.nombre}' de usuario '{user.nombre_usuario}': {e}", exc_info=True)
            raise

# Implementa funciones similares para la relación usuario_empresa si es necesario